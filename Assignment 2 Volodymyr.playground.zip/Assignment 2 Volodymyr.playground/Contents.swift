import UIKit

//********************15*********************
let player = (name: "Igor Larinov", number: 8)


//********************16*********************

let name = "Igor Larinov"
let number: Int = 8

let player1:String = String(name) + " number " +  String(number)


//********************17*********************

//let value: Int? = nil
//print(value)
//let otherValue: Int? = 6
//print(otherValue)

//********************18*********************


// We need to add default value to it to unwrap it

let value: Int? = 17
let defaultValue = 18

let banana: Int = value ?? defaultValue


// or we can to force unwrap it adding ! to the vale

//********************19*********************


//let value2: Int? = nil
//let banana2: Int = value2!

//It will show an error



//********************20*********************

// create for it a default value or create a direct value  value for example

let banana2: Int = 20
    print(banana2)

//********************21*********************
let valueOne = 100
let valueTwo = 100

var sum = valueTwo + valueOne

if valueOne == valueTwo {
    print(sum * 3)
} else {
    print(sum)
}


//********************22*********************
var numbers = [1, 3, 5, 10, 7]

if numbers.contains(5) {
    print("This array contains 5")
} else {
    print("There is no 5 in this array")
}


//********************23*********************
var reversedArray = [10, 20, 30, 40, 50, 60, 70]
reversedArray.reverse()
print(reversedArray)



//********************24*********************
func rotate_left(_ newArray: [Int]) -> [Int] {
    var rotatedArray = newArray
    rotatedArray.removeFirst()
    rotatedArray.append(newArray.first!)
    return rotatedArray
}

print(rotate_left([1, 2, 3]))


//********************25*********************
let newNumbers = [2, 10, 5, 7]
let newSum = newNumbers.reduce(0, +)
print(newSum)




//********************26*********************
func differeceOf_51(n: Int) -> Int {
    if n > 51 {
        return (n - 51) * 2
    } else {
        return 51 - n
    }
}

print(differeceOf_51(n: 52))
print(differeceOf_51(n: 23))
print(differeceOf_51(n: 67))


//********************27*********************
func returnTrue(a: Int, b: Int) -> Bool {
    if a + b == 20 || a == 20 || b  == 20   {
        return true
    } else {
        return false
    }
}

print(returnTrue(a: 10, b: 10))
print(returnTrue(a: 10, b: 49))


//********************28*********************
func negativeTrue(a: Int, b: Int) -> Bool {
    if a > 0 && b < 0 {
        return true
    } else if a < 0 && b > 0 {
        return true
    } else if a < 0 && b < 0 {
        return true
    } else {
        return false
    }
}
print(negativeTrue(a: 20, b: 10))
print(negativeTrue(a: -8, b: 9))


//********************29*********************
func inRangeOf10_30(a: Int, b: Int) -> Bool {
    
    if   a >= 10 && a <= 30  {
        return true
    } else if b >= 10 && b <= 30 {
        return true
    } else {
        return false
    }
}

print(inRangeOf10_30(a: 3, b: 5))
print(inRangeOf10_30(a: 10, b: 7))
print(inRangeOf10_30(a: 9, b: 30))



//********************30*********************
func firstAndLastChar(_ typedWord: String) -> String {
    
    var str = typedWord
    
    let firstChar = String(str.prefix(1))
    
    let lastChar = String(str.suffix(1))
    
    str.removeFirst()
    str.removeLast()
    
    return lastChar + str + firstChar
    
}

print(firstAndLastChar("mana"))
