
// Volodymyr Navorotskyi

// ****** Exercise 1 *********************
var currentTemperature: Float = 17.67891
print(currentTemperature)

currentTemperature = 23.12347
print(currentTemperature)

// ****** Exercise 2 *********************

let numberOfSecondsInHour = 3600

//numberOfSecondsInHour = 4000
// it will not work beacuse we can't change a value of a constant. I we want to change it we need let change to var

// ****** Exercise 3 *********************

var newNum: Int = 23
var  numTwo = 45

// ****** Exercise 4 *********************
let numberOfWheels: Int

numberOfWheels = 4
/* we can create a constant that doesn’t have a value just yet, later we can provide that value, and Swift will ensure we don’t accidentally use it until a value is present. It will also ensure that you only ever set the value once, so that it remains constant.
 */



// ****** Exercise 5 *********************
let π = 3.14159
print(π)


// ****** Exercise 6 *********************
var 🦩 = "Flamingo"


// ****** Exercise 7 *********************
print(🦩)


// ****** Exercise 8 *********************
/* Max Value of Int16 is 32767 */
//let pi = 3 + 0.141592654
/* it is an Double because Float Pi only has a 7 digits accuracy.The Double Pi has 15 digits accuracy*/

// ****** Exercise 9 *********************
//let myNumber: UInt = -17
// It show an error because UInt min value can be 0, not negative.



// ****** Exercise 10 *********************
//let bigNumber: Int16 = 32767 + 1
/*we will receive an error, overflow.
max value of Int16 can be 32767*/



// ****** Exercise 11 *********************

let pi = 3.141592654
let approximatePi: Int = Int(pi)
//we need to add Int before pe because to convert two values it has to be the same types. Right now pi is a double and we need to convert it to Int



// ****** Exercise 12 *********************

// Hello World
/* Hello World*/


// ****** Exercise 13 *********************

/* Hello all the people in the world
 /* even animals */
!!!!*/


// ****** Exercise 14 *********************

Hello World. It is not a comment
