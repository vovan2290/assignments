import UIKit


// Volodymyr Navorotskyi

//****************** 1 *************************
func addTwoNumbers(n1: Int, n2: Int) -> Int {
    let sum = n1 + n2
    return sum
}

var result = addTwoNumbers(n1: 2, n2: 4)

print("The sum is \(result)")


//**************** 2 ***************************

// The Error of that code is that we can not add 3 different types of values. We adding Int, Float and Double and it's gives an error. If We create or convert them into one type for example Double, Float Or Int it will work

let n1: Int = 1
let n2: Float = 2.0
let n3: Double = 3.34

var result2 = Double(n1) + Double(n2) + n3

print(result2)




//**************** 3 ***************************

/* An initializer is a special type of function that is used to create an object of a class or struct.  Initializers are called to create a new instance of a particular type. In its simplest form, an initializer is like an instance method with no parameters, written using the init keyword:
 
 init() {
     // perform some initialization here
 }
 
 */


//**************** 4 ***************************

/* A protocol defines a blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality. The protocol can then be adopted by a class, structure, or enumeration to provide an actual implementation of those requirements. Any type that satisfies the requirements of a protocol is said to conform to that protocol.

*/


protocol Greet {

  // blueprint of a property
  var name: String { get }


  // blueprint of a method
  func message()
}

// conform class to Greet protocol
class Employee: Greet {

  // implementation of property
  var name = "John"

  // implementation of method
  func message() {
    print("Hello!", name)
  }
}

var employee1 = Employee()
employee1.message()


//**************** 5 ***************************

/* Double question mark is a nil-coalescing operator. In plain terms, it is just a shorthand for saying != nil . First it checks if the the return value is nil, if it is indeed nil, then the left value is presented, and if it is nil then the right value is presented. */

// Without ??:
// a != nil ? a! : b
// With ??:
// a ?? b

//**************** 6 ***************************


/* In Swift, we use the guard statement to transfer program control out of scope when certain conditions are not met.
 
 The guard statement is similar to the if statement with one major difference. The if statement runs when a certain condition is met. However, the guard statement runs when a certain condition is not met.


  */


//**************** 7 ***************************

/* There are three primary collection types, known as arrays, sets, and dictionaries, for storing collections of values. Arrays are ordered collections of values. Sets are unordered collections of unique values. Dictionaries are unordered collections of key-value associations  */

//**************** 8 ***************************

/* structs are value types where as classes are reference types. When we copy a struct, we end up with two unique copies of the data. When we copy a class, we end up with two references to one instance of the data. It's a crucial difference, and it affects our choice between classes or structs.  */


//**************** 9 ***************************

/* Optional chaining is a process for querying and calling properties, methods, and subscripts on an optional that might currently be nil. If the optional contains a value, the property, method, or subscript call succeeds; if the optional is nil, the property, method, or subscript call returns nil. Multiple queries can be chained together, and the entire chain fails gracefully if any link in the chain is nil.

 We specify optional chaining by placing a question mark (?) after the optional value on which you wish to call a property, method or subscript if the optional is non-nil. This is very similar to placing an exclamation point (!) after an optional value to force the unwrapping of its value. The main difference is that optional chaining fails gracefully when the optional is nil, whereas forced unwrapping triggers a runtime error when the optional is nil.
 */


//**************** 10 ***************************

/* Optional binding is a mechanism built into Swift to safely unwrap optionals. Since an optional may or may not contain a value, optional binding always has to be conditional. To enable this, conditional statements in Swift support optional binding, which checks if a wrapped value actually exists. If it does, the wrapped value gets extracted as a temporary constant or variable, which is available within the scope normally associated with the conditional statement.
 
 An if statement is the most common way to unwrap optionals through optional binding. We can do this by using the let keyword immediately after the if keyword, and following that with the name of the constant to which we want to assign the wrapped value extracted from the optional. Here is a simple example.  */

//example

struct Car {
    var brand = "Audi"
    var fixedYesOrNot = true
    
    func canDrive() {
        print("The car is fixed and you can drive")
    }
}

var fixedOrNot: Car? = Car()

if let car = fixedOrNot {
    car.canDrive()
}


//**************** 11 ***************************

/* inout parameters allow us to change an input passed into a function. In Swift, changing the value of a parameter passed into a function is not possible. This is because a function argument is a constant, and constants cannot be modified. An inout parameter is a special type of parameter that can be modified inside a function and the changes apply outside the function. */

//for example

func change(_ age: inout Int ) {
    age = 23
}

var age = 28

change(&age)
print(age)

//**************** 12 ***************************

/* We can define a default value for any parameter in a function by assigning a value to the parameter after that parameter's type. If a default value is defined, we can omit that parameter when calling the function. */

//**************** 13 ***************************

/* We can use force unwrapping when we 100% sure that optional is not a nil. We can use it when our code is absolutely guaranteed to be safe.  */

//example of force unwrapping
enum Direction: CaseIterable {
    case north, south, east, west
}

let randomDirection = Direction.allCases.randomElement()!

// in this cae we know that we have 4 cases and we can use force unwrapping

//**************** 14 ***************************

/* The mutating keyword is only required if we are changing any state contained within the struct. Since Swift structs are immutable objects, calling a mutating function actually returns a new struct in-place, much like passing an inout parameter to a function. The mutating keyword lets callers know that the method is going to make the value change */

//example

struct MyStruct {
    var name: String = "Leo"

    mutating func changeValue() {
        name = "Jonne"
   }
}


//**************** 15 ***************************

/* Deinitialization is a process to deallocate class instances when they're no longer needed. This frees up the memory space occupied by the system.
 
 We use the deinit keyword to create a deinitializer.   */

class Game {
  

  // create deinitializer
  deinit {
    // perform deinitialization
    
  }
}
    
    //**************** 16 ***************************

/* a protocol defines a blueprint of methods or properties that can then be adopted by classes (or any other types).  */


   protocol Say {

      // blueprint of a property
      var word: String { get }


      // blueprint of a method
      func message()
    }


//**************** 17 ***************************
    
/* protocol describes what an unknown type of object can do. We might say it has two or three properties of various types, plus methods. But that protocol never includes anything inside the methods, or provides actual storage for the properties.
 
 In a more advanced form, we can write extensions on your protocols that provide default implementations of the methods. We still can’t provide storage for properties, however.

 In comparison, classes are concrete things. While they might adopt protocols – i.e., say they implement the required properties and methods – they aren’t required to do that. You can create objects from classes, whereas protocols are just type definitions. We can call  protocols as being abstract definitions, whereas classes and structs are real things we can create.  */
    


//**************** 18 ***************************

//The else block of a guard statement requires an exit path.
struct Apple {

}

func pick(apple: Apple?) {
  guard let apple = apple else {
    print("No apple found!")
      return
  }
  print(apple)
}

//**************** 19 ***************************

/* We can inherit multiple protocols in the same class.
   Also we can inherit multiple protocols in a single protocol but we can not inherit multiple classes in a one class
 */

protocol Payable {
    func calculateWages() -> Int
}

protocol NeedsTraining {
    func study()
}

protocol HasVacation {
    func takeVacation(days: Int)
}


class Employee2: Payable, NeedsTraining, HasVacation {
    func takeVacation(days: Int) {
        print("Vacation")
    }
    
    func study() {
        print("Study")
    }
    
    func calculateWages() -> Int {
        return 200
    }
    
    
}


//**************** 20 ***************************


var first = ["John", "Paul"]
let second = ["George", "Ringo"]


//we can use different methods to append arrays


let thirdArray = first + second
print(thirdArray)

//another way

first += second

//another way
first.append(contentsOf: second)


